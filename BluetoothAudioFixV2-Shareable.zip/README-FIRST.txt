Bluetooth Audio Fix V2 — Shareable Revenge Plugin

WHAT IT DOES
Blocks Discord/Revenge Bluetooth SCO / hands-free routing calls so compatible
Bluetooth headphones can stay in normal stereo media mode during voice calls.

PLUGIN HASH
SHA-256(index.js): ea85ca20263b8947f8b2ef2e4447065e5e71750a4725b7723639e6ef29a48269

FILES
BluetoothAudioFixV2/
  manifest.json
  index.js

QUICK INSTALL — SAME DEVICE
If Termux and Revenge are on the same Android device:

1. Extract this ZIP.
2. In Termux:
   pkg install python unzip -y
   cd /path/to/the/extracted/folder
   python -m http.server 8080 --bind 0.0.0.0

3. In Revenge -> Plugins -> Add, paste:
   http://127.0.0.1:8080/BluetoothAudioFixV2

4. Enable "Bluetooth Audio Fix V2".
5. Fully force-close and reopen Revenge.
6. Once installed and tested, the local server can normally be stopped because
   Revenge stores the downloaded plugin locally.

IMPORTANT
- Disable older Bluetooth Audio Fix / A2DP Keeper plugins while testing this one.
- This is intended for Revenge/Vendetta-compatible Discord builds.
- If Discord changes its audio bridge again, the plugin may need updating.

DEBUG
ADB/logcat:
  adb logcat -d | grep -i "BTAudioFixV2"

Expected lines include:
  [BTAudioFixV2] patched ...
  [BTAudioFixV2] BLOCKED ...
